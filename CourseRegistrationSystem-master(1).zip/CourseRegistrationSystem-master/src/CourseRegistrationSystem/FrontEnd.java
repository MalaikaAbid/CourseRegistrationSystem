package CourseRegistrationSystem;


import javax.swing.*;
import java.awt.*;
import java.io.IOException; 
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.util.Scanner;


/**
 * Handles client-side operations with a GUI for the user to select
 * commands for the Course Registration System from.
 * @author Alex Belanger and Malaika Abid
 * @version 1.1
 * @since August 8, 2021
 */
public class FrontEnd extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private PrintWriter socketOut;
	private BufferedReader socketIn;
	
    JFrame f;
    JPanel buttonPanel;
    JPanel textFieldPanel;
    JPanel textAreaPanel;
    JPanel studentPanel;
    JPanel coursePanel;
    JTextField  studentName = new JTextField(5);
    JTextField studentID= new JTextField(5);
    JTextField courseName = new JTextField(5);
    JTextField courseID = new JTextField(5);
    String response = "";
    Object[] studentMessage = {"Student Name: ", studentName, "Student ID: ", studentID}; 
    Object[] courseMessage = { "Course Name: ", courseName,"Course Number: ", courseID};

	public FrontEnd (Client client) {
		socketIn = client.getSocketIn();
		socketOut = client.getSocketOut();
		
		//Setting layout for GUI
		 f = new JFrame("Frame1");
	        buttonPanel = new JPanel();
	        textFieldPanel = new JPanel();
	        textAreaPanel = new JPanel();
	        studentPanel = new JPanel();
	        coursePanel = new JPanel();
	        
	        JButton b1 = new JButton("Search Catalogue Courses");
	        JButton b2 = new JButton("Add Course To Student Courses");
	        JButton b3 = new JButton("Remove Course From Student Catalogue");
	        JButton b4 = new JButton("View all courses in catalogue");
	        JButton b5 = new JButton("View all courses taken by student");

	        studentPanel.add(new JLabel("Student Name:"));
	        studentPanel.add(new JLabel("Student ID:"));
	        coursePanel.add(new JLabel("Course Name:"));
	        coursePanel.add(new JLabel("Course ID:"));
	        studentPanel.add(studentName);
	        studentPanel.add(studentID);
	        coursePanel.add(courseName);
	        coursePanel.add(courseID);
	        JTextField windowTitle = new JTextField();
	        windowTitle.setText("Course Registration System");
	        windowTitle.setEditable(false);
	        textFieldPanel.add(windowTitle);
	        JTextArea textArea = new JTextArea();
	        textArea.setEditable(false);
	        JScrollPane scroll = new JScrollPane(textArea);
	        textAreaPanel.add(scroll,BorderLayout.EAST);
	        
	        
	        
	        /**
	         * Button 5 prompts user for student information, then 
	         * displays all courses for the student selected.
	         */
	        b5.addActionListener(new ActionListener(){
	            public void actionPerformed(ActionEvent e){
	            	socketOut.println("5");
	            try {
					findStudent();
				} catch (IOException e1) {
					System.out.println("Operation Cancelled!");
				}
				try {
					
					/**
					 * Newlines are handled on the client side by replacing all 
					 * ~ characters with a new line. This is to navigate around
					 * an issue with the socketOut.println() function and multi-line
					 * strings.
					 */
					String unformatted = socketIn.readLine();
					String formatted = unformatted.replace("~","\n");
					textArea.setText(formatted);
				} catch (IOException e1) {
					System.out.println("Operation Cancelled!");
				}
	            textAreaPanel.repaint();
	            }
	        });
	        
	        /**
	         * Button 4 displays all courses stored in the system's
	         * course catalogue.
	         */
	        b4.addActionListener(new ActionListener(){
	            public void actionPerformed(ActionEvent e){
	            	socketOut.println("4");
					try {
						String unformatted = socketIn.readLine();
						
						String formatted = unformatted.replace("~","\n");
						textArea.setText(formatted);
					} catch (IOException e1) {
						System.out.println("Operation Cancelled!");
					}
	            }
	        });

	        /**
	         * Button 3 prompts user for student information and
	         * course information, then attempts to remove the
	         * selected student from the selected course.
	         * 
	         */
	        b3.addActionListener(new ActionListener(){
	            public void actionPerformed(ActionEvent e){
	            	socketOut.println("3");
	            	try {
	            	findStudent();
					try {
						Thread.sleep(5);
					} catch (InterruptedException e1) {
						System.out.println("Operation Cancelled!");
					}
					enterCourse();
	            	}
	            	catch(IOException e1){
	            		System.out.println("Operation Cancelled!");
	            	}
					try {
						String unformatted = socketIn.readLine();	
						String formatted = unformatted.replace("~","\n");
						textArea.setText(formatted);
					} catch (IOException e1) {
						System.out.println("Operation Cancelled!");
					}
	            }
	        });

	        /**
	         * Button 2 prompts user for student information and
	         * course information, then attempts to add the 
	         * selected course to the selected student's course list.
	         */
	        b2.addActionListener(new ActionListener(){
	            public void actionPerformed(ActionEvent e){
	            	socketOut.println("2");
	            
					try {
						findStudent();
					} catch (IOException e2) {
						// TODO Auto-generated catch block
					
					}
	           
	        		   
				 
				try {
					enterCourse();
				} catch (IOException e1) {
					System.out.println("Operation Cancelled!");
				}
				try {
					String unformatted = socketIn.readLine();
					
					String formatted = unformatted.replace("~","\n");
					textArea.setText(formatted);
				} catch (IOException e1) {
					System.out.println("Operation Cancelled!");
				}
	            textAreaPanel.repaint();
	            }
	        });


	        /**
	         * Button 1 promps user for course information, then
	         * displays that course if it exists in the course catalogue.
	         */
	        b1.addActionListener(new ActionListener(){
	            public void actionPerformed(ActionEvent e){
	            	socketOut.println("1");
					try {
						enterCourse();
					} catch (IOException e1) {
						System.out.println("Operation Cancelled!");
					}
					try {
						String unformatted = socketIn.readLine();
						
						String formatted = unformatted.replace("~","\n");
						textArea.setText(formatted);
					} catch (IOException e1) {
						System.out.println("Operation Cancelled!");
					}
	            }
	        });

	        f.setSize(1500,400);
	        f.setTitle("Main Window");
	        f.add(buttonPanel,BorderLayout.SOUTH);
	        f.add(textAreaPanel,BorderLayout.CENTER);
	        f.add(scroll,BorderLayout.CENTER);
	        f.add(textFieldPanel,BorderLayout.NORTH);
	        buttonPanel.add(b1);
	        buttonPanel.add(b2);
	        buttonPanel.add(b3);
	        buttonPanel.add(b4);
	        buttonPanel.add(b5);
	        f.setVisible(true);
	        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

	
	/**
	 * Prompts user for course name and number then attemps to find.
	 * @throws IOException
	 */
	private void enterCourse() throws IOException
	{
		
		
		courseName.setText("");
		courseID.setText("");
		int option = JOptionPane.showConfirmDialog(null, courseMessage,"Input", JOptionPane.OK_CANCEL_OPTION);
		if (option == JOptionPane.OK_OPTION) {
			if(courseName.getText() != null && courseID.getText() != null) {
		    socketOut.println(courseName.getText());
		    socketOut.println(courseID.getText());
		    return;
			}
			else {
				JOptionPane.showMessageDialog(null, "Please fill out all fields", "Error", JOptionPane.ERROR_MESSAGE);
				socketOut.println("soup");
			    socketOut.println("2");
			    return;
				
			}
		}
		else {
			System.err.println("Input canceled");
		    socketOut.println("soup");
		    socketOut.println("2");
			return;
		
		}
	}

	
	
	/**
	 * Prompts user for student name and ID then attempts to find.
	 * @throws IOException
	 */
	private void findStudent() throws IOException
	{

		studentName.setText("");
		studentID.setText("");
		int option = JOptionPane.showConfirmDialog(null, studentMessage,"Input", JOptionPane.OK_CANCEL_OPTION);
		if (option == JOptionPane.OK_OPTION) {
			if(studentName.getText().isEmpty() || studentID.getText().isEmpty() ) {
				JOptionPane.showMessageDialog(null, "Please fill out all fields", "Error", JOptionPane.ERROR_MESSAGE);
				socketOut.println("error");
			    socketOut.println("1");
			    return;
		    
		   
			}
			else {
				socketOut.println(studentName.getText());
				socketOut.println(studentID.getText());
			    return;

			}
		}
		else {
			System.err.println("Input canceled");
			socketOut.println("soup4Error");
		    socketOut.println("4");
		    return;
		}
		    

	}
	
}




